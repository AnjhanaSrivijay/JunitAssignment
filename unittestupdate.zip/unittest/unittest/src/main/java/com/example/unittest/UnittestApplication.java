package com.example.unittest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnittestApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnittestApplication.class, args);
	}

}
